<?php
$con = mysqli_connect("localhost","u1556303_admin","S1s3m0csS1s3m0cs","u1556303_hourmeter");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
?>