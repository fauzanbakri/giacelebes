<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

include 'config.php';
$q3 = $con->query("SELECT email FROM data_email");
$q = $con->query("SELECT * FROM hour_data");
foreach($q as $row){
    // echo $row['id'];
$q2 = $con->query("SELECT SUM(total_runtime) AS a FROM data_history WHERE id_alat='$row[id]'");
$r = $q2 -> fetch_assoc();
    if($r['a']>$row['time_notification'] && $row['notif']=='0' ){
        $response = false;  
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host     = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'port.makassar@gmail.com';
        $mail->Password = 'uskesfhotjknqzrr';
        $mail->SMTPSecure = 'ssl';
        $mail->Port     = 465;
        $mail->setFrom('admin@sisemocs.com', '');
        $mail->addReplyTo('port.makassar@gmail.com', '');
        foreach($q3 as $row3){
            $mail->addAddress($row3['email']);
        }
        $mail->Subject = 'Time Limit Reached';
        $mail->isHTML(true);
        $mail->Body =
        //start
        '<html>
        <head>
        <style>
        table, th, td {
          border: 0px solid black;
          border-collapse: collapse;
          position: center;
          font-size: 20px;
        }
        table.center {
          margin-left: auto; 
          margin-right: auto;
        </style>
        </head>
        
        <body>
        <table style="width:100%">
          <thead style="background-color:black">
          <tr>
            <td colspan = "4"><h2 style="color:white"><b><center>Hour Meter Notification</center></b></h2></td>
          </tr>
          </thead>
          
          <tbody>
            <tr style="color:red">
              <td colspan = "3"><p><b style="font-size:20px">Batas Waktu Pengoperasian Mesin Telah Tercapai</b></p></td>
            </tr>
        
            <tr>
              <td colspan = "3"><p>Dear Admin Hour Meter</p></td>
            </tr>
            
            <tr>
              <td colspan = "3"><p>Kami mengirimkan pemberitahuan ini untuk mengingatkan anda bahwa mesin di bawah ini telah mencapai batas waktu pengoperasian.</p></td>
            </tr>    
          </tbody>
         </table>
         
        <table class="center" style="background-color:#D5D0CF">
            <tr>
              <td width= 200px, padding-left= 10px>Engine ID</td>
              <td width= 20px><center>:</center></td>
              <td width= 200px><b>'.$row['id'].'</b></td>
            </tr>
            
            <tr >
              <td>Engine Name</td>
              <td><center>:</center></td>
              <td><b>'.$row['name'].'</b></td>
            </tr>
            <tr>
              <td>Total Runtime</td>
              <td><center>:</center></td>
              <td style="color:blue"><b>'.$r['a'].'</b></td>
            </tr>
            <tr>
              <td>Limit Runtime</td>
              <td><center>:</center></td>
              <td style="color:red"><b>'.$row['time_notification'].'</b></td>
            </tr>
        </table>
            
        <table width= 100%>
            <thead>
              <tr >
                <td colspan = "4"><p>Silakan kunjungi https://sisemocs.com untuk reset waktu pengoperasian mesin. Anda juga dapat menambah batas waktu pengoperasian mesin jika tidak ingin reset mesin. Mohon untuk untuk mengaktifkan kembali status notifikasi setelah mengatur waktu pengoperasian mesin agar kami dapat mengirimkan pemberitahuan setelah waktu pengoperasian mesin tercapai.</p></td>
              </tr>
          </thead>
        </table>
        </body>
        </html>
        ';
        //end

        if(!$mail->send()){
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
            echo 'Message has been sent';
            echo $row['id'];
            $q=$con->query("UPDATE hour_data SET notif=1 WHERE id='$row[id]'");
        }
        $mail->clearAddresses();
        $mail->clearAttachments();
    }
}
    
?>