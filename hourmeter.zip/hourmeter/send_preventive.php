<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

include 'config.php';
$q3 = $con->query("SELECT email FROM data_email");
$q = $con->query("SELECT * FROM preventive");
foreach($q as $row){
    // echo $row['id'];
$prev_id = $row['id_prev'];
$r = $q -> fetch_assoc();
    if($row['notif_date']<= date("Y-m-d") && $row['exec_date']=='0000-00-00' ){
        $response = false;  
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host     = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'port.makassar@gmail.com';
        $mail->Password = 'uskesfhotjknqzrr';
        $mail->SMTPSecure = 'ssl';
        $mail->Port     = 465;
        $mail->setFrom('admin@sisemocs.com', '');
        $mail->addReplyTo('port.makassar@gmail.com', '');
        foreach($q3 as $row3){
            $mail->addAddress($row3['email']);
        }
        $mail->Subject = 'Preventive Notification';
        $mail->isHTML(true);
        $mail->Body =
        //start
        '<html>
        <head>
        <style>
        table, th, td {
          border: 0px solid black;
          border-collapse: collapse;
          position: center;
          font-size: 20px;
        }
        table.center {
          margin-left: auto; 
          margin-right: auto;
        </style>
        </head>
        
        <body>
        <table style="width:100%">
          <thead style="background-color:black">
          <tr>
            <td colspan = "4"><h2 style="color:white"><b><center>Preventive Notification</center></b></h2></td>
          </tr>
          </thead>
          
          <tbody>
            <tr>
              <td colspan = "3"><p>Dear Admin Hour Meter</p></td>
            </tr>
            
            <tr>
              <td colspan = "3"><p>Kami mengirimkan pemberitahuan ini untuk mengingatkan anda bahwa preventive berikut telah mencapai tanggal plan pengerjaan.</p></td>
            </tr>    
          </tbody>
         </table>
         
        <table class="center" style="background-color:#D5D0CF"><center>
            <tr>
              <td width= 200px, padding-left= 10px>ID Preventive</td>
              <td width= 20px><center>:</center></td>
              <td width= 200px><b>'.$row['id_prev'].'</b></td>
            </tr>
            
            <tr>
              <td width= 200px, padding-left= 10px>ID Alat</td>
              <td width= 20px><center>:</center></td>
              <td width= 200px><b>'.$row['id_alat'].'</b></td>
            </tr>
            
            <tr >
              <td>Detail Preventive</td>
              <td><center>:</center></td>
              <td><b>'.$row['prev_name'].'</b></td>
            </tr>
            <tr>
              <td>Plan Date</td>
              <td><center>:</center></td>
              <td><b>'.$row['plan_date'].'</b></td>
        </table>
            
        <table width= 100%>
            <thead>
              <tr >
                <td colspan = "4"><p>Silahkan tekan tombol <b>DONE</b> jika preventive tersebut telah dieksekusi. Abaikan email ini jika belum mengerjakan preventive tersebut.</p></td>
              </tr>
          </thead>
        </table>
        
        <table width= 100%>
            <thead>
              <tr>
                <td colspan="3"><center>
                <button style="background-color:#5cb85c">
                    <a href="https://sisemocs.com/hourmeter/execdate_update.php?id='.$row['id_prev'].'">DONE</a>
                </button>
              </td>
          </thead>
        </table>
        </body>
        </html>
        ';
        //end

        if(!$mail->send()){
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
            echo 'Message has been sent';
            echo $row['id_prev'];
            $q=$con->query("UPDATE preventive SET notif_date = DATE_ADD(notif_date, INTERVAL 1 DAY) WHERE id_prev='$row[id_prev]'");
        }
        $mail->clearAddresses();
        $mail->clearAttachments();
    }
}
    
?>
