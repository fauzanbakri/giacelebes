<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Makassar extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		if(empty($_SESSION['role'])){
			header("location:login");
		}
		// $this->load->view('header');
		$this->load->view('makassar');
		// $this->load->view('footer');
	}

	public function marker(){
		$q1 = $this->db->query("SELECT *  FROM jetty1 where status='1'")->num_rows();
		$q2 = $this->db->query("SELECT *  FROM jetty2 where status='1'")->num_rows();
		$q3 = $this->db->query("SELECT *  FROM booking where status='1'")->num_rows();
		if ($q1>0 && $q2>0 && $q3>0){
			echo "123";
		}else if ($q1>0 && $q2==0 && $q3==0){
			echo "1";
		}else if ($q1>0 && $q2>0 && $q3==0){
			echo "12";
		}else if ($q1>0 && $q2==0 && $q3>0){
			echo "13";
		}else if ($q1==0 && $q2>0 && $q3==0){
			echo "2";
		}else if ($q1==0 && $q2>0 && $q3>0){
			echo "23";
		}else if ($q1==0 && $q2==0 && $q3>0){
			echo "3";
		}else{
			echo "0";
		}
	}

	public function jetty3_list()
	{
		$query = $this->db->query("SELECT booking.*, name  FROM booking,user where status='1' AND booking.id_user=user.id_user ORDER BY time_start DESC");
		if($query->num_rows()>0){
			foreach ($query->result() as $row)
			{
					echo '
						<div class="accordion-item rounded mt-2">
	                        <div id="collapseTwo" class="accordion-collapse border-0" aria-labelledby="headingTwo" data-bs-parent="#buyingquestion" style="">
	                            <div class="accordion-body bg-white">
	                            <label class="form-label">'.$row->ship_name.'</label>&nbsp;<label>('.$row->name.')</label><br>
	                                <label>Waktu Booking : &nbsp;</label><label>'.$row->time_start.'</label><br>
	                                <label>Waktu Selesai : &nbsp;</label><label>'.$row->time_end.'</label><br>
	                                <label>Estimasi : &nbsp;</label><label>'.$row->estimasi.'</label><label>&nbsp;Jam</label><br>
	                            </div>
	                        </div>
	                    </div>
					';
			}
		}else{
			echo "<center>No Data</center>";
		}
	}
	public function jetty1_berthed(){
		$query = $this->db->query("SELECT * FROM jetty1 where status='0' ORDER BY id_jetty ASC");
		if($query->num_rows()>0){
			foreach ($query->result_array() as $row) {
			echo '
				<div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">'.$row['nama_kapal'].'</span></div>
			';	
			}
		}else{
			echo '<center><div class=""><i class="uil uil-newspaper h3 mb-0"></i><span class="ms-1">No Data</span></div></center>';
		}
	}
	public function jetty2_berthed(){
		$query = $this->db->query("SELECT * FROM jetty2 where status='0' ORDER BY id_jetty ASC");
		if($query->num_rows()>0){
			foreach ($query->result_array() as $row) {
			echo '
				<div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">'.$row['nama_kapal'].'</span></div>
			';	
			}
		}else{
			echo '<center><div class=""><i class="uil uil-newspaper h3 mb-0"></i><span class="ms-1">No Data</span></div></center>';
		}
	}
	public function jetty1_list(){
		$query = $this->db->query("SELECT * FROM jetty1 where status='1' ORDER BY id_jetty DESC limit 1");
		if($query->num_rows()>0){
			$row = $query->row_array();
					echo '
						<div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">'.$row["nama_kapal"].'</span></div>
                        <div class="mb-2"><img src="images/lastport.png" width="20px"><span class="ms-4">'.$row["last_port"].'</span></div>
                        <div class="mb-2"><img src="images/ata.png" width="20px"><span class="ms-4">'.$row["ATA"].'</span></div>
                        <div class="mb-2"><img src="images/berthed.png" width="20px"><span class="ms-4">'.$row["berthed"].'</span></div>
                        <div class="mb-2"><img src="images/cargo.png" width="20px"><span class="ms-4">'.$row["cargo"].'</span></div>
                        <div class="mb-2"><img src="images/bunker.png" width="20px"><span class="ms-4">'.$row["bunker"].'</span></div>
                        <div class="mb-2"><img src="images/nextport.png" width="20px"><span class="ms-4">'.$row["next_port"].'</span></div>
                        <div class="mb-2"><img src="images/etc.png" width="20px"><span class="ms-4">'.$row["etc"].'</span></div>
					';
		}else{
			echo '<center><div class=""><i class="uil uil-newspaper h3 mb-0"></i><span class="ms-1">No Data</span></div></center>';
		}
	}

	public function jetty2_list()
	{
		$query = $this->db->query("SELECT * FROM jetty2 where status='1' ORDER BY id_jetty DESC LIMIT 1");
		if($query->num_rows()>0){
			$row = $query->row_array();
					echo '
						<div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">'.$row["nama_kapal"].'</span></div>
                        <div class="mb-2"><img src="images/lastport.png" width="20px"><span class="ms-4">'.$row["last_port"].'</span></div>
                        <div class="mb-2"><img src="images/ata.png" width="20px"><span class="ms-4">'.$row["ATA"].'</span></div>
                        <div class="mb-2"><img src="images/berthed.png" width="20px"><span class="ms-4">'.$row["berthed"].'</span></div>
                        <div class="mb-2"><img src="images/cargo.png" width="20px"><span class="ms-4">'.$row["cargo"].'</span></div>
                        <div class="mb-2"><img src="images/bunker.png" width="20px"><span class="ms-4">'.$row["bunker"].'</span></div>
                        <div class="mb-2"><img src="images/nextport.png" width="20px"><span class="ms-4">'.$row["next_port"].'</span></div>
                        <div class="mb-2"><img src="images/etc.png" width="20px"><span class="ms-4">'.$row["etc"].'</span></div>
					';
		}else{
			echo '<center><div class=""><i class="uil uil-newspaper h3 mb-0"></i><span class="ms-1">No Data</span></div></center>';
		}
	}
	public function dateslidedec(){
		if($this->input->post('date')==''){
				$datenow = date("Y-m-d");
		}else{
				$date = $this->input->post('date');
				// $datenow = date("Y-m-d", strtotime($date));  
				// $date = date("Y-m-d"); 
				 $datenow = date("Y-m-d", strtotime("-1 days", strtotime($date)));
		}
		
		$query = $this->db->query("SELECT * FROM booking WHERE DATE(time_start)>='$datenow' AND DATE(time_start)<='$datenow' AND status='1'");
		if($query->num_rows()>0){
		    echo '
			<div class="text-center align-items-center border-0 bg-light">
            		<h4 style="color: #2f55d4" id="today">'.date("d M Y", strtotime($datenow)).'</h4>
            </div>';
			foreach ($query->result_array() as $row) {
			echo '
            <div class=" shadow rounded">
                    <div class="ps-5 pe-5 accordion-body text-muted bg-white" id="jetty3regist">
	                    <div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">'.$row["ship_name"].'</span></div>
	            		<div class="mb-2"><img src="images/etc.png" width="20px"><span style="font-size: 14px" class="ms-4">'.substr($row["time_start"], 11).' - '.substr($row["time_end"], 11).'</span></div>
            		</div>
            </div>
			';	
		}
		}else{
			echo '
			<div class="text-center align-items-center border-0 bg-light">
            		<h4 style="color: #2f55d4" id="today">'.date("d M Y", strtotime($datenow)).'</h4>
            </div>
            <div>
                    <div class="ps-5 pe-5 accordion-body text-muted bg-white" id="jetty3regist">
	                    <center><div class=""><i class="uil uil-newspaper h3 mb-0"></i><span class="ms-1">No Data</span></div></center>
            		</div>
            </div>
			';
		}
	}
	public function dateslideadd(){
		if($this->input->post('date')==''){
				$datenow = date("Y-m-d");
		}else{
				$date = $this->input->post('date');
				// $datenow = date("Y-m-d", strtotime($date));  
				// $date = date("Y-m-d"); 
				$datenow = date("Y-m-d", strtotime("+1 days", strtotime($date)));
		}
		
		$query = $this->db->query("SELECT * FROM booking WHERE DATE(time_start)>='$datenow' AND DATE(time_start)<='$datenow' AND status='1'");
		if($query->num_rows()>0){
			echo '
			<div class="text-center align-items-center border-0 bg-light">
            		<h4 style="color: #2f55d4" id="today">'.date("d M Y", strtotime($datenow)).'</h4>
            </div>';
			foreach ($query->result_array() as $row) {
			echo '
            <div class=" shadow rounded">
                    <div class="ps-5 pe-5 accordion-body text-muted bg-white" id="jetty3regist">
	                    <div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">'.$row["ship_name"].'</span></div>
	            		<div class="mb-2"><img src="images/etc.png" width="20px"><span style="font-size: 14px" class="ms-4">'.substr($row["time_start"], 11).' - '.substr($row["time_end"], 11).'</span></div>
            		</div>
            </div>
			';	
			}
		}else{
			echo '
			<div class="text-center align-items-center border-0 bg-light">
            		<h4 style="color: #2f55d4" id="today">'.date("d M Y", strtotime($datenow)).'</h4>
            </div>
            <div>
                    <div class="ps-5 pe-5 accordion-body text-muted bg-white" id="jetty3regist">
	                    <center><div class=""><i class="uil uil-newspaper h3 mb-0"></i><span class="ms-1">No Data</span></div></center>
            		</div>
            </div>
			';
		}
	}
	public function loadDate(){
		if($this->input->post('date')==''){
				$datenow = date("Y-m-d");
		}else{
				$date = $this->input->post('date');
				// $datenow = date("Y-m-d", strtotime($date));  
				// $date = date("Y-m-d"); 
				$datenow = date("Y-m-d", strtotime("+1 days", strtotime($date)));
		}
		
		$query = $this->db->query("SELECT * FROM booking WHERE time_start>='$datenow' AND time_start<='$datenow' AND status='1'");
		if($query->num_rows()>0){
			foreach ($query->result_array() as $row) {
			echo '
			<div class="text-center align-items-center border-0 bg-light">
            		<h4 style="color: #2f55d4" id="today">'.date("d M Y", strtotime($datenow)).'</h4>
            </div>
            <div>
                    <div class="ps-5 pe-5 accordion-body text-muted bg-white" id="jetty3regist">
	                    <div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">'.$row["nama_kapal"].'</span></div>
	            		<div class="mb-2"><img src="images/etc.png" width="20px"><span style="font-size: 14px" class="ms-4">'.$row["time_start"].' - '.$row["time_end"].'</span></div>
            		</div>
            </div>
			';	
			}
		}else{
			echo '<center><div class=""><i class="uil uil-newspaper h3 mb-0"></i><span class="ms-1">No Data</span></div></center>';
		}
	}
} 
