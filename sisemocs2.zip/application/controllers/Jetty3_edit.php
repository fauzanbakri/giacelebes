<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jetty3_edit extends CI_Controller {

	public function index()
	{
		if(empty($_SESSION['role'])){
			header("location:login");
		}


		if ($this->input->get('id')!=""){
			$id = $this->input->get('id');
			$data['data'] = $this->db->query("SELECT * FROM booking where id_booking='$id'");
			$data['id'] = $id;




			$this->load->view('jetty3_edit', $data);
		}else{
			header("location:listBooking");
		}
	
	}
	public function cek(){
		$time_start = $this->input->post('str');
		$time_end = $this->input->post('end');
		$id = $this->input->post('id');

		$query = $this->db->query("SELECT * from booking WHERE (id_booking!='$id' AND '$time_start' BETWEEN time_start AND time_end) OR (id_booking!='$id' AND '$time_end' BETWEEN time_start AND time_end) OR (id_booking!='$id' AND '$time_start' < time_start AND '$time_end' > time_end);");
		if($query->num_rows()>0){
			echo "exist";
		}else{
			echo "notexist";
		}

	}

	public function edit(){
		$id = $this->input->post("id");
		$status_loading = $this->input->post("status_loading");
		$namakapal = $this->input->post("namakapal");
		$loadingproduct = $this->input->post("loadingproduct");
		$nominasi = $this->input->post("nominasi");
		$time_start = $this->input->post("start");
		$time_end = $this->input->post("end");
		$request_tambahan = $this->input->post("req");
		$status = $this->input->post("status");
		$tujuan = $this->input->post("tujuan");

	    $input = $this->db->query("UPDATE booking SET nominasi_loading='$nominasi', status_loading='$status_loading', status='$status', time_start='$time_start', time_end='$time_end', ship_name='$namakapal', tujuan='$tujuan', loading_product='$loadingproduct', request_tambahan='$request_tambahan' WHERE id_booking='$id'");
	    if($input){
	         header('location: ../listBooking');
	    }
	      
	}
}
