<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AddUser extends CI_Controller {
	public function index()
	{
		if(empty($_SESSION['role'])){
			header("location:login");
		}
		// $this->load->view('header');
		$this->load->view('addUser');
		// $this->load->view('footer');
	}
	public function add(){
		$nama = $this->input->post('nama');
		$username = $this->input->post('username');
		$password = md5($this->input->post('password'));
		$role = $this->input->post('role');

		$query = "INSERT INTO user (name,username,password,role) VALUES ('$nama','$username','$password','$role')";
		if($this->db->query($query)){
			header("location:../success");
		}else{
			header("location:../error");
		}
	}
	public function checkusername(){
		$username = $this->input->post('username');
		$query = "SELECT username FROM user where username='$username'";
		$res = $this->db->query($query);
		if ($res->num_rows()>0) {
			echo "error";
		}else{
			echo "success";
		}

	}
}
