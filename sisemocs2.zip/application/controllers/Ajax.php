<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function booking_list()
	{
		$query = $this->db->query("SELECT * FROM booking ORDER BY time_start DESC");

		foreach ($query->result() as $row)
		{
				echo '
					<li>
						<div class="cbp_tmtime" style="margin-top:7px">'.$row->time_start.' '.$row->time_end.'</div>
						<i class="cbp_tmicon rounded-x hidden-xs"></i>
						<div class="cbp_tmlabel" style="padding-top: 17px">
							<a style="font-size:16px">'.$row->ship_name.'</a>
						</div>
					</li>
				';
		}
	}
}
