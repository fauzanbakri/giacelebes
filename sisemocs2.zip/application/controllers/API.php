<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class API extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	
	}
	public function login()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$sql = $this->db->query("SELECT * FROM user WHERE username='$email' AND password='$password'");
		$result = array();
		$result['login'] = array();
		if ($sql->num_rows()>0) {
			$row = $sql->row_array();
			$index['id_user'] = $row['id_user'];
			$index['email'] = $row['email'];
			$index['name'] = $row['name'];
			
			array_push($result['login'], $index);
			$result['success'] = "1";
			$result['message'] = "success";
			echo json_encode($result);
	
		}else{
			$result = array(
				'success' => "0",
				'message' => "error"
			);
			echo json_encode($result);

		}
	}
	public function weather(){
		$url = 'https://api.weather.com/v2/pws/observations/current?stationId=IMAKAS3&format=json&units=e&apiKey=4dd9c44d5243495099c44d5243c95038';
		$ch = curl_init($url);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	    $response = curl_exec($ch);
	    curl_close($ch);
	    echo $response;

	}
}
