<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Detail extends CI_Controller {
	public function index()
	{
		if(empty($_SESSION['role'])){
			header("location:login");
		}
		// $this->load->view('header');
		$this->load->view('detail');
		// $this->load->view('footer');
	}
}
