<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jetty3 extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		if(empty($_SESSION['role'])){
			header("location:login");
		}
		// $this->load->view('header');
		$this->load->view('jetty3');
		// $this->load->view('footer');
		// $this->upload("hahaha");
	}

	public function cek(){
		$time_start = $this->input->post('start');
		$time_end = $this->input->post('end');

		$query = $this->db->query("SELECT * from booking WHERE ('$time_start' BETWEEN time_start AND time_end) OR ('$time_end' BETWEEN time_start AND time_end) OR ('$time_start' < time_start AND '$time_end' > time_end);");
		if($query->num_rows()>0){
			echo "exist";
		}else{
			echo "notexist";
		}

	}


	public function upload(){
	// $this->load->library('upload');
	// if (isset($_POST['submit'])){
	$id_user = $_SESSION['id_user'];
	$namakapal = $this->input->post("namakapal");
	$status = $this->input->post("status");
	$loadingproduct = $this->input->post("loadingproduct");
	$nominasi = $this->input->post("nominasi");
	$time_start = $this->input->post("start");
	$time_end = $this->input->post("end");
	$tujuan = $this->input->post("tujuan");
	$req = $this->input->post("req");
	$request_tambahan = $this->input->post("req");

	$morring = rand(0,999999999999999999).basename($_FILES['morring']['name']);
	$ukuran_file_1 = ($_FILES['morring']['size']);
	$tmp_1 = ($_FILES['morring']['tmp_name']);
	$type_1 = ($_FILES['morring']['type']);
	$tujuan_1 =  "assets/uploads/morring_unmorring/".$morring;
	$link_1 = base_url($tujuan_1);

	$bmbb = rand(0,999999999999999999).basename($_FILES['bmbb']['name']);
	$ukuran_file_2 = ($_FILES['bmbb']['size']);
	$tmp_2 = ($_FILES['bmbb']['tmp_name']);
	$type_2 = ($_FILES['bmbb']['type']);
	$tujuan_2 =  "assets/uploads/bmbb/".$bmbb;
	$link_2 = base_url($tujuan_2);
	
	$lo = rand(0,999999999999999999).basename($_FILES['LO']['name']);
	$ukuran_file_3 = ($_FILES['LO']['size']);
	$tmp_3 = ($_FILES['LO']['tmp_name']);
	$type_3 = ($_FILES['LO']['type']);
	$tujuan_3 =  "assets/uploads/LO/".$lo;
	$link_3 = base_url($tujuan_3);

	$pakta = rand(0,999999999999999999).basename($_FILES['pakta']['name']);
	$ukuran_file_4 = ($_FILES['pakta']['size']);
	$tmp_4 = ($_FILES['pakta']['tmp_name']);
	$type_4 = ($_FILES['pakta']['type']);
	$tujuan_4 =  "assets/uploads/pakta_integritas/".$pakta;
	$link_4 = base_url($tujuan_4);

	if($ukuran_file_1 <= 500000000 || $ukuran_file_2 <= 500000000 || $ukuran_file_3 <= 500000000 || $ukuran_file_4 <= 500000000){

	        $upload_1 = move_uploaded_file($tmp_1,$tujuan_1);
	        $upload_2 = move_uploaded_file($tmp_2,$tujuan_2);
	        $upload_3 = move_uploaded_file($tmp_3,$tujuan_3);
	        $upload_4 = move_uploaded_file($tmp_4,$tujuan_4);
	        if($upload_1 && $upload_2 && $upload_3 && $upload_4){

	        $input = $this->db->query("INSERT INTO booking (id_user, time_start, time_end, ship_name, status, tujuan, nominasi_loading, request_tambahan, morring, bmbb, lo, pakta_integritas, status_loading, loading_product) VALUES('$id_user', '$time_start', '$time_end', '$namakapal', 0, '$tujuan', '$nominasi', '$request_tambahan', '$link_1', '$link_2', '$link_3', '$link_4', '$status', '$loadingproduct')");

	                //jika query input sukses
	                if($input){
	                     header('location: ../makassar');
	                    
	                 }
	        }
      }
	}
	// }
}
