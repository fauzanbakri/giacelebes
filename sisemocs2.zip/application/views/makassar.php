

<!DOCTYPE html>
    <html lang="en">

    
<!-- Mirrored from shreethemes.in/landrick/layouts/job-list-four.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 11 Jul 2021 09:14:15 GMT -->
<head>
        <meta charset="utf-8" />
        <title>Makassar</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Premium Bootstrap 5 Landing Page Template" />
        <meta name="keywords" content="Saas, Software, multi-uses, HTML, Clean, Modern" />
        <meta name="author" content="Shreethemes" />
        <meta name="email" content="support@shreethemes.in" />
        <meta name="website" content="https://shreethemes.in/" />
        <meta name="Version" content="v3.5.0" />
        <!-- favicon -->
        <link rel="shortcut icon" href="images/sisemocs-logo3.png">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- Icons -->
        <link href="css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/line.css">
        <link href="css/simplebar.css" rel="stylesheet" type="text/css" />
        <!-- Main Css -->
        <link href="css/style.min.css" rel="stylesheet" type="text/css" id="theme-opt" />
        <link href="css/colors/default.css" rel="stylesheet" id="color-opt">
        <link rel="stylesheet" type="text/css" href="css/slide.css">

    </head>

    <body>
        <!-- Loader -->
        <!-- <div id="preloader">
            <div id="status">
                <div class="spinner">
                    <div class="double-bounce1"></div>
                    <div class="double-bounce2"></div>
                </div>
            </div>
        </div> -->
        <!-- Loader -->
        
        <!-- Navbar STart -->
        <header id="topnav" class="defaultscroll sticky bg-white">
            <div class="container">
                <!-- Logo container-->
                <a class="logo" href="index.html">
                    <img src="images/sisemocs-logo1.png" height="40" class="logo-light-mode" alt="">
                    <img src="images/logo-light.png" height="24" class="logo-dark-mode" alt="">
                </a>
                
                <!-- Logo End -->

                <!-- End Logo container-->
                <div class="menu-extras">
                    <div class="menu-item">
                        <!-- Mobile menu toggle-->
                        <a class="navbar-toggle" id="isToggle" onclick="toggleMenu()">
                            <div class="lines">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </a>
                        <!-- End mobile menu toggle-->
                    </div>
                </div>

                <!--Login button Start-->
                <ul class="buy-button list-inline mb-0">
                    <li class="list-inline-item mb-0">
                        <a href="javascript:void(0)" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                            <div class="nav-light"><?php echo $_SESSION['name']; ?></div>
                        </a>
                    </li>
                    
                    <li class="list-inline-item ps-1 mb-0">
                        <a href="login/logout">
                            <div class="login-btn-primary"><span class="btn btn-icon btn-pills btn-primary"><i data-feather="log-out" class="fea log-out"></i></span></div>
                            <div class="login-btn-light"><span class="btn btn-icon btn-pills btn-light"><i data-feather="log-out" class="fea log-out"></i></span></div>
                        </a>
                    </li>
                </ul>
                <!--Login button End-->
        
                <div id="navigation">
                    <!-- Navigation Menu-->   
                    <ul class="navigation-menu">
                        <li><a href="home" class="sub-menu-item">Home</a></li>
                        <li class="has-submenu parent-parent-menu-item">
                            <a href="javascript:void(0)">Port List</a><span class="menu-arrow"></span>
                            <ul class="submenu">
                                <li class="has-submenu parent-menu-item"><a href="javascript:void(0)"> Sulawesi </a><span class="submenu-arrow"></span>
                                    <ul class="submenu">
                                        <li><a href="Makassar" class="has-submenu parent-menu-item">Makassar</a>
                                            <?php 
                                                if ($_SESSION['role']==1){
                                                    echo '
                                                    <span class="submenu-arrow"></span>
                                                    <ul class="submenu">
                                                        <li><a href="jetty3" class="sub-menu-item">Jetty 3</a></li>
                                                    </ul>
                                                    ';
                                                }else if ($_SESSION['role']==2){
                                                    echo '
                                                    <span class="submenu-arrow"></span>
                                                    <ul class="submenu">
                                                        <li><a href="jetty3" class="sub-menu-item">Jetty 3</a></li>
                                                    </ul>
                                                    ';
                                                }else if ($_SESSION['role']==3){
                                                    echo '
                                                    <span class="submenu-arrow"></span>
                                                    <ul class="submenu">
                                                        <li><a href="listbooking" class="sub-menu-item">Data</a></li>
                                                        <li><a href="jetty1" class="sub-menu-item">Jetty 1</a></li>
                                                        <li><a href="jetty2" class="sub-menu-item">Jetty 2</a></li>
                                                        <li><a href="jetty3" class="sub-menu-item">Jetty 3</a></li>
                                                    </ul>
                                                    ';
                                                }
                                             ?>
                                            
                                        </li>
                                        <li><a href="#" class="sub-menu-item">Bau-Bau</a></li>
                                        <li><a href="#" class="sub-menu-item">Poso</a></li>
                                        <li><a href="#" class="sub-menu-item">Donggala</a></li>
                                        <li><a href="#" class="sub-menu-item">Raha</a></li>
                                        <li><a href="#" class="sub-menu-item">Kendari</a></li>
                                        <li><a href="#" class="sub-menu-item">Moutong</a></li>
                                        <li><a href="#" class="sub-menu-item">Pare-pare</a></li>
                                        <li><a href="#" class="sub-menu-item">Toli-toli</a></li>
                                        <li><a href="#" class="sub-menu-item">Palopo</a></li>
                                        <li><a href="#" class="sub-menu-item">Gorontalo</a></li>
                                        <li><a href="#" class="sub-menu-item">Kolonedale</a></li>
                                        <li><a href="#" class="sub-menu-item">Bitung</a></li>
                                        <li><a href="#" class="sub-menu-item">Banggai</a></li>
                                        <li><a href="#" class="sub-menu-item">Tahuna</a></li>
                                        <li><a href="#" class="sub-menu-item">Luwuk</a></li>
                                    </ul> 
                                </li>   
                            </ul>
                        </li>
                        <?php  
                        if ($_SESSION['role']==3){ 
                            echo '<li><a href="addUser" class="sub-menu-item">Add User</a></li>';
                        }else{
                        }

                        ?>
                    </ul><!--end navigation menu-->
                </div><!--end navigation-->
            </div><!--end container-->
        </header><!--end header-->
        <!-- Navbar End -->
        
        <!-- Hero Start -->
        <section style="padding-top: 100px">
        <div class="container">
                    <h6>View Makassar</h6>
        </div>
                    <div id="map" style="height: 400px"></div>
        </section><!--end section-->
        <!-- Hero End -->

        <!-- Shape Start -->
        <!--Shape End-->
        
        <!-- Job List Start -->
        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="border-bottom pb-4">
                            <div class="row">
                                <div class="col-lg-9 col-md-8">
                                    <div class="section-title">
                                        
                                    </div>
                                </div><!--end col-->
            
                                <div class="col-lg-3 col-md-4">
                                    <div class="form custom-form">
                                            <label class="form-label">Halaman Detail : </label>
                                            <a href="detail" class="btn btn-outline-primary">Detail</a>
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->

                <div class="row">
                    <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <label class="form-label">JETTY 1</label>
                    <div class="row">
                        <div class="col-md-12 col-12">
                    	<div class="d-flex align-items-center features feature-clean shadow rounded p-4">
                            <div class="icons text-primary text-center">
                                <i class="uil uil-wind-sun d-block rounded h3 mb-0"></i><p style="font-size: 10px">Wind Speed</p><h5>0Kn</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil uil-temperature-three-quarter d-block rounded h3 mb-0"></i><p style="font-size: 10px">Temperature</p><h5>0°C</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil uil-raindrops-alt d-block rounded h3 mb-0"></i><p style="font-size: 10px">Humidity</p><h5>0%</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil  uil-tachometer-fast-alt d-block rounded h3 mb-0"></i><p style="font-size: 10px">Pressure</p><h5>0In</h5>
                            </div>
                        </div>
                        </div>
                    </div>
                    <label class="mt-4 form-label">Vessel at Jetty 1</label>
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <div class=" shadow rounded p-4" id="jetty1">
                            
                        </div>
                        </div>
                    </div>
                    <label class="mt-4 form-label">Next Berthing Plan Jetty 1</label>
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <div class=" shadow rounded p-4" id="jetty1berth">
                            
                        </div>
                        </div>
                    </div>
                    </div><!--end col-->

                    <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <label class="form-label">JETTY 2</label>	
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <div class="d-flex align-items-center features feature-clean shadow rounded p-4">
                            <div class="icons text-primary text-center">
                                <i class="uil uil-wind-sun d-block rounded h3 mb-0"></i><p style="font-size: 10px">Wind Speed</p><h5>0Kn</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil uil-temperature-three-quarter d-block rounded h3 mb-0"></i><p style="font-size: 10px">Temperature</p><h5>0°C</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil uil-raindrops-alt d-block rounded h3 mb-0"></i><p style="font-size: 10px">Humidity</p><h5>0%</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil  uil-tachometer-fast-alt d-block rounded h3 mb-0"></i><p style="font-size: 10px">Pressure</p><h5>0In</h5>
                            </div>
                        </div>
                        </div>  
                    </div>
                    <label class="mt-4 form-label">Vessel at Jetty 2</label>
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <div class=" shadow rounded p-4" id="jetty2">
                            
                        </div>
                        </div>
                    </div>
                    <label class="mt-4 form-label">Next Berthing Plan Jetty 2</label>
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <div class=" shadow rounded p-4" id="jetty2berth">
                            
                        </div>
                        </div>
                    </div>
                    
                    </div><!--end col-->

                    <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <label class="form-label">JETTY 3 </label>
                    <div class="row">
                    	<div class="col-md-12 col-12">
                        <div class="d-flex align-items-center features feature-clean shadow rounded p-4">
                            <div class="icons text-primary text-center">
                                <i class="uil uil-wind-sun d-block rounded h3 mb-0"></i><p style="font-size: 10px">Wind Speed</p><h5 id="wind">0Kn</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil uil-temperature-three-quarter d-block rounded h3 mb-0"></i><p style="font-size: 10px">Temperature</p><h5 id="temperature">0°C</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil uil-raindrops-alt d-block rounded h3 mb-0"></i><p style="font-size: 10px">Humidity</p><h5 id="humidity">0%</h5>
                            </div>
                            <div class="icons text-primary ms-3 text-center">
                                <i class="uil  uil-tachometer-fast-alt d-block rounded h3 mb-0"></i><p style="font-size: 10px">Pressure</p><h5 id="pressure">0In</h5>
                            </div>
                        </div>
                        </div> 
                    </div>
                    <label class="mt-4 form-label">Jetty 3 Vessel Registered</label>
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <div class=" shadow rounded p-0">
                        <div id="date_data">   
                                
                        </div>
                                <a class="prev" onclick="prevdate()">&#10094;</a>
                                <a class="next" onclick="nextdate()">&#10095;</a>

                            
                        </div>
                        </div>
                    </div>
                    <!-- <label class="mt-4 form-label">Next Berthing Plan Jetty 3</label>
                    <div class="row">
                        <div class="col-md-12 col-12">
                        <div class=" shadow rounded p-4">
                            <div class="mb-2"><img src="images/shipicon.png" width="20px"><span class="ms-4">MT. ABCD</span></div>
                        </div>
                        </div>
                    </div> -->
                    </div>
                   

                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- Job List End -->

        <!-- Footer Start -->
        <footer class="footer">    
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="footer-py-60">
                            <div class="row">
                                <div class="col-lg-4 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                                    <a href="#" class="logo-footer">
                                        <img src="assets/images/pertamina.png" height="40" alt="">
                                    </a>
                                    <p class="mt-4">Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                    <ul class="list-unstyled social-icon foot-social-icon mb-0 mt-4">
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="rounded"><i data-feather="linkedin" class="fea icon-sm fea-social"></i></a></li>
                                    </ul><!--end icon-->
                                </div><!--end col-->
                                
                                <div class="col-lg-2 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <h5 class="footer-head">Company</h5>
                                    <ul class="list-unstyled footer-list mt-4">
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> About us</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Services</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Team</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Pricing</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Project</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Careers</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Blog</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Login</a></li>
                                    </ul>
                                </div><!--end col-->
                                
                                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <h5 class="footer-head">Usefull Links</h5>
                                    <ul class="list-unstyled footer-list mt-4">
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Terms of Services</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Privacy Policy</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Documentation</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Changelog</a></li>
                                        <li><a href="javascript:void(0)" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> Components</a></li>
                                    </ul>
                                </div><!--end col-->
            
                                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <h5 class="footer-head">Newsletter</h5>
                                    <p class="mt-4">Sign up and receive the latest tips via email.</p>
                                    <form>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe mb-3">
                                                    <label class="form-label">Write your email <span class="text-danger">*</span></label>
                                                    <div class="form-icon position-relative">
                                                        <i data-feather="mail" class="fea icon-sm icons"></i>
                                                        <input type="email" name="email" id="emailsubscribe" class="form-control ps-5 rounded" placeholder="Your email : " required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="d-grid">
                                                    <input type="submit" id="submitsubscribe" name="send" class="btn btn-soft-primary" value="Subscribe">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->

            <div class="footer-py-30 footer-bar">
                <div class="container text-center">
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="text-sm-start">
                                <p class="mb-0">© <script>document.write(new Date().getFullYear())</script> Landrick. Design with <i class="mdi mdi-heart text-danger"></i> by <a href="https://shreethemes.in/" target="_blank" class="text-reset">Shreethemes</a>.</p>
                            </div>
                        </div><!--end col-->
    
                        <div class="col-sm-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                            <ul class="list-unstyled text-sm-end mb-0">
                                <li class="list-inline-item"><a href="javascript:void(0)"><img src="images/payments/american-ex.png" class="avatar avatar-ex-sm" title="American Express" alt=""></a></li>
                                <li class="list-inline-item"><a href="javascript:void(0)"><img src="images/payments/discover.png" class="avatar avatar-ex-sm" title="Discover" alt=""></a></li>
                                <li class="list-inline-item"><a href="javascript:void(0)"><img src="images/payments/master-card.png" class="avatar avatar-ex-sm" title="Master Card" alt=""></a></li>
                                <li class="list-inline-item"><a href="javascript:void(0)"><img src="images/payments/paypal.png" class="avatar avatar-ex-sm" title="Paypal" alt=""></a></li>
                                <li class="list-inline-item"><a href="javascript:void(0)"><img src="images/payments/visa.png" class="avatar avatar-ex-sm" title="Visa" alt=""></a></li>
                            </ul>
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end container-->
            </div>
        </footer><!--end footer-->
        <!-- Footer End -->

        <!-- Offcanvas Start -->
        <div class="offcanvas offcanvas-end bg-white shadow" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
            <div class="offcanvas-header p-4 border-bottom">
                <h5 id="offcanvasRightLabel" class="mb-0">
                    <img src="images/logo-dark.png" height="24" class="light-version" alt="">
                    <img src="images/logo-light.png" height="24" class="dark-version" alt="">
                </h5>
                <button type="button" class="btn-close d-flex align-items-center text-dark" data-bs-dismiss="offcanvas" aria-label="Close"><i class="uil uil-times fs-4"></i></button>
            </div>
            <div class="offcanvas-body p-4">
                <div class="row">
                    <div class="col-12">
                        <img src="images/contact.svg" class="img-fluid d-block mx-auto" style="max-width: 256px;" alt="">
                        <div class="card border-0 mt-5" style="z-index: 1">
                            <div class="card-body p-0">
                                <form method="post" name="myForm" onsubmit="return validateForm()">
                                    <p id="error-msg" class="mb-0"></p>
                                    <div id="simple-msg"></div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Your Name <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="user" class="fea icon-sm icons"></i>
                                                    <input name="name" id="name" type="text" class="form-control ps-5" placeholder="Name :">
                                                </div>
                                            </div>
                                        </div>
    
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Your Email <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="mail" class="fea icon-sm icons"></i>
                                                    <input name="email" id="email" type="email" class="form-control ps-5" placeholder="Email :">
                                                </div>
                                            </div> 
                                        </div><!--end col-->
    
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Subject</label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="book" class="fea icon-sm icons"></i>
                                                    <input name="subject" id="subject" class="form-control ps-5" placeholder="subject :">
                                                </div>
                                            </div>
                                        </div><!--end col-->
    
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Comments <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="message-circle" class="fea icon-sm icons clearfix"></i>
                                                    <textarea name="comments" id="comments" rows="4" class="form-control ps-5" placeholder="Message :"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="d-grid">
                                                <button type="submit" id="submit" name="send" class="btn btn-primary">Send Message</button>
                                            </div>
                                        </div><!--end col-->
                                    </div><!--end row-->
                                </form>
                            </div>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div>

            <div class="offcanvas-footer p-4 border-top text-center">
                <ul class="list-unstyled social-icon social mb-0">
                    <li class="list-inline-item mb-0"><a href="https://1.envato.market/4n73n" target="_blank" class="rounded"><i class="uil uil-shopping-cart align-middle" title="Buy Now"></i></a></li>
                    <li class="list-inline-item mb-0"><a href="https://dribbble.com/shreethemes" target="_blank" class="rounded"><i class="uil uil-dribbble align-middle" title="dribbble"></i></a></li>
                    <li class="list-inline-item mb-0"><a href="https://www.facebook.com/shreethemes" target="_blank" class="rounded"><i class="uil uil-facebook-f align-middle" title="facebook"></i></a></li>
                    <li class="list-inline-item mb-0"><a href="https://www.instagram.com/shreethemes/" target="_blank" class="rounded"><i class="uil uil-instagram align-middle" title="instagram"></i></a></li>
                    <li class="list-inline-item mb-0"><a href="https://twitter.com/shreethemes" target="_blank" class="rounded"><i class="uil uil-twitter align-middle" title="twitter"></i></a></li>
                    <li class="list-inline-item mb-0"><a href="mailto:support@shreethemes.in" class="rounded"><i class="uil uil-envelope align-middle" title="email"></i></a></li>
                    <li class="list-inline-item mb-0"><a href="https://shreethemes.in/" target="_blank" class="rounded"><i class="uil uil-globe align-middle" title="website"></i></a></li>
                </ul><!--end icon-->
            </div>
        </div>
        <!-- Offcanvas End -->

        <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fs-5"><i data-feather="arrow-up" class="fea icon-sm icons align-middle"></i></a>
        <!-- Back to top -->

        <!-- Style switcher -->
        
        <!-- end Style switcher -->

        <!-- javascript -->
        <script src="js/bootstrap.bundle.min.js"></script>
        <!-- Icons -->
        <script src="js/simplebar.min.js"></script>
        <script src="js/feather.min.js"></script>
        <!-- Switcher -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="js/switcher.js"></script>
        <!-- Main Js -->
        <script src="js/plugins.init.js"></script><!--Note: All init js like tiny slider, counter, countdown, maintenance, lightbox, gallery, swiper slider, aos animation etc.-->
        <script src="js/app.js"></script><!--Note: All important javascript like page loader, menu, sticky menu, menu-toggler, one page menu etc. -->
        <script type="text/javascript">
				function list(){	
					$.ajax({
			            url: "Makassar/jetty3_list",
			            type: 'GET',
			            dataType: 'text',
			            success: function (data) {
			            	// console.log(data.observations[0].imperial.temp);
			                $('#list').html(data);      
			            }
			        });
				}

				function list_jetty1(){	
					$.ajax({
			            url: "Makassar/jetty1_list",
			            type: 'GET',
			            dataType: 'text',
			            success: function (data) {
			            	// console.log(data.observations[0].imperial.temp);
			                $('#jetty1').html(data);      
			            }
			        });
				}

                function berth_jetty1(){ 
                    $.ajax({
                        url: "Makassar/jetty1_berthed",
                        type: 'GET',
                        dataType: 'text',
                        success: function (data) {
                            // console.log(data.observations[0].imperial.temp);
                            $('#jetty1berth').html(data);      
                        }
                    });
                }
                function berth_jetty2(){ 
                    $.ajax({
                        url: "Makassar/jetty2_berthed",
                        type: 'GET',
                        dataType: 'text',
                        success: function (data) {
                            // console.log(data.observations[0].imperial.temp);
                            $('#jetty2berth').html(data);      
                        }
                    });
                }

				function list_jetty2(){	
					$.ajax({
			            url: "Makassar/jetty2_list",
			            type: 'GET',
			            dataType: 'text',
			            success: function (data) {
			            	// console.log(data.observations[0].imperial.temp);
			                $('#jetty2').html(data);      
			            }
			        });
				}

				function wunder(){
					$.ajax({
			            url: "https://api.weather.com/v2/pws/observations/current?stationId=IJENEP1&format=json&units=e&apiKey=4dd9c44d5243495099c44d5243c95038",
			            type: 'GET',
			            dataType: 'json',
			            success: function (data) {
			            	// console.log(data.observations[0].imperial.temp);
			                $('#wind').html(Math.round(data.observations[0].imperial.windSpeed/1.151)+"Kn");
			                $('#pressure').html(data.observations[0].imperial.pressure+"In");
			                $('#humidity').html(data.observations[0].humidity+"%");
			                $('#temperature').html(Math.round((parseInt(data.observations[0].imperial.temp)-32)*5/9)+"°C");
			            }
			        });
				}
				list();
                berth_jetty1();
                berth_jetty2();
				list_jetty1();
				list_jetty2();
				wunder();
				setInterval(function(){ 
					list();
					wunder();
				}, 30000);
        </script>
        <script src="https://maps.google.com/maps/api/js?key=AIzaSyDzWZ3TJQ0Z_qy3__1yNaBgCiXQAP8-NBk"></script>

        <script type="text/javascript">
            var center = new google.maps.LatLng(-5.113129,119.411269);

            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 16,
                center: center,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            });
            var point = new google.maps.LatLng(-5.216776,119.430534);
            
        </script>
        <script type="text/javascript">
                $.ajax({
                    url:    "Makassar/marker",
                    type : 'POST',
                    success : function(data) {
                        console.log(data);
                        if (data=='123') {
                            var jetty1 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.113412,119.409320),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty1, 'click', (function() {
                                    window.location.href = "jetty1";
                            }));
                            var jetty2 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.111435,119.412710),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty2, 'click', (function() {
                                    window.location.href = "jetty2";
                            }));
                            var jetty3 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.112253,119.410286),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty3, 'click', (function() {
                                    window.location.href = "jetty3";
                            }));
                        }else if (data=='1') {
                            var jetty1 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.113412,119.409320),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty1, 'click', (function() {
                                    window.location.href = "jetty1";
                            }));
                        }else if (data=='12') {
                            var jetty1 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.113412,119.409320),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty1, 'click', (function() {
                                    window.location.href = "jetty1";
                            }));
                            var jetty2 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.111435,119.412710),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty2, 'click', (function() {
                                    window.location.href = "jetty2";
                            }));
                        }else if (data=='13') {
                            var jetty1 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.113412,119.409320),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty1, 'click', (function() {
                                    window.location.href = "jetty1";
                            }));
                            var jetty3 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.112253,119.410286),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty3, 'click', (function() {
                                    window.location.href = "jetty3";
                            }));
                        }else if (data=='2') {
                            var jetty2 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.111435,119.412710),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty2, 'click', (function() {
                                    window.location.href = "jetty2";
                            }));
                        }else if (data=='23') {
                            var jetty2 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.111435,119.412710),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty2, 'click', (function() {
                                    window.location.href = "jetty2";
                            }));
                            var jetty3 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.112253,119.410286),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty3, 'click', (function() {
                                    window.location.href = "jetty3";
                            }));
                        }
                        else if (data=='3') {
                            var jetty3 = new google.maps.Marker({
                                    position: new google.maps.LatLng(-5.112253,119.410286),
                                    icon: 'images/ship.png',
                                    map: map
                                });

                            google.maps.event.addListener(jetty3, 'click', (function() {
                                    window.location.href = "jetty3";
                            }));
                        }
                    }
                });


        function prevdate(){
            var date = $('#today').text();
            $.ajax({
                    url: "Makassar/dateslidedec",
                    type: 'POST',
                    dataType: 'text',
                    data: {date:date},
                    success: function (data) {
                        // console.log(data.observations[0].imperial.temp);
                        $('#date_data').html(data);      
                    }
            });
        }

        function nextdate(){
            var date = $('#today').text();
            $.ajax({
                    url: "Makassar/dateslideadd",
                    type: 'POST',
                    dataType: 'text',
                    data: {date:date},
                    success: function (data) {
                        // console.log(data.observations[0].imperial.temp);
                        $('#date_data').html(data);      
                    }
            });

        }

        function today(){
            $.ajax({
                url: "Makassar/loadDate",
                type: 'GET',
                dataType: 'text',
                success: function(data){
                    $('#date_data').html(data);      
                }
            });
        }
        nextdate();
        </script>

    </body>

<!-- Mirrored from shreethemes.in/landrick/layouts/job-list-four.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 11 Jul 2021 09:14:17 GMT -->
</html>