<?php
$dashboard = 'active';
$addnew = '';
$email = '';
$recenthistory = '';
$history = '';
session_start();
if(!isset($_SESSION['name'])){
  header('location: index.php');
}
include "header.php";
$q = $con->query("SELECT * FROM hour_data WHERE id='$_GET[id]'");
$row = mysqli_fetch_array($q);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Data</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit Data</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="form" method="post" action="edit_action.php" enctype="multipart/form-data" id="quickForm">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">ID :</label>
                    <input readonly type="text" name="id" id="input_id" required value="<?php echo $row['id']?>" class="form-control" placeholder="Enter ID">
                  </div>
                    <div id="notif" class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <label><i class="icon fas fa-ban"></i> ID Already Exist!</label>
                    </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Name :</label>
                    <input type="text" name="name" id="input_name" required value="<?php echo $row['name']?>" class="form-control" placeholder="Enter Name">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Description :</label>
                    <input type="text" name="description" id="input_desc" required value="<?php echo $row['engine_description']?>" class="form-control" placeholder="Enter Description of The Engine">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Fuel :</label>
                    <input type="text" name="fuel" required id="input_fuel" value="<?php echo $row['engine_fuel']?>" class="form-control" placeholder="Enter Engine's Fuel Type">
                  </div>
                  <div class="form-group">
                      <div class=col-sm-6 float=left>
                        <label for="exampleInputPassword1">Hour :</label>
                        <input type="number" name="time_hour" required id="input_hour" value="<?php echo intval($row['time_notification']/60)?>" class="form-control" max="100" step="1" min="0" value="0" placeholder="Enter Engine's Fuel Type">
                      </div>
                      <div class=col-sm-6 float=right>
                        <label for="exampleInputPassword1">Minute :</label>
                        <input type="number" name="time_minute" required id="input_minute" value="<?php echo $row['time_notification']%60?>" max="59" step="1" min="0" value="0" class="form-control" placeholder="Enter Engine's Fuel Type">
                      </div>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Notification Status :</label><br>
                    <input type="checkbox" name="status-checkbox" <?php if($row['notif']==0){echo 'checked';}?> id="input_status" class="form-control" data-bootstrap-switch data-off-color="danger" data-on-color="primary">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputFile">Upload Image :</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" id="input_img" class="custom-file-input" name="engine_image" value="<?php echo $row['engine_picture']?>">
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                      </div>
                    </div>
                  </div>
                </div>
                <input type="hidden" id="old_img" class="custom-file-input" name="old_image" value="<?php echo $row['engine_picture']?>">
                <!-- /.card-body -->
                <div class="card-footer">
                  <button id="sbm" type="submit" name="sbm" type="button" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.2.0-rc
    </div>
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->
<!-- Page specific script -->
<!-- SweetAlert2 -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
<!-- Bootstrap Switch -->
<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/inputmask/jquery.inputmask.min.js"></script>

<script>
$.ajax({
  url: "load_data.php",
  type: 'GET',
  success: function (data) {
      $('#example1').html(data);
  }   
});

$("#form").on('submit',(function(e) {
  e.preventDefault();
  var id = $('#input_id').val();
  var name = $('#input_name').val(); 
  var desc = $('#input_desc').val();
  var fuel = $('#input_fuel').val();
  var hour = $('#input_hour').val();
  var minute = $('#input_minute').val();
  var status = $('#input_status').val();
  var fd = new FormData(this);
  // var img = fd.append('file', $('#input_img').get(0).files[0]);
  $.ajax({
  url: "edit_action.php",
  type: 'POST',
  data:  new FormData(this),
   contentType: false,
   processData:false,
  success: function (data) {
      if (data=="ok"){
        toastr.success('Insert Success');
        window.setTimeout(function(){
        window.location.href = "index.php";
        }, 5000);      
    }else{
      toastr.error(data);
    }
  }   
  });
}));
</script>
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["excel","print"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<script>
     $("#notif").attr("hidden", "true");
    $( "#input_id" ).keyup(function() {
       
        var id=$('#input_id').val();
        $.ajax({
        url: "cek_id.php",
        type: 'POST',
        data: {id:id},
        success: function (data) {
            console.log(data);
            if(data=="ok"){
                $("#notif").attr("hidden", true);
                $("#sbm").prop("disabled", false);
            }else{
                $("#notif").attr("hidden", false);
                $("#sbm").prop("disabled", true);
            }
        }
    });
});
</script>

<script>
  function login(){
    var username = $('#inputUsername').val();
    var pass = $('#inputPassword').val();
    $.ajax({
    url: "login.php",
    type: 'POST',
    data: {user:username, pass:pass},
    success: function (data) {
      if(data=="ok"){
        location.reload();
      }else{
        alert("Wrong Username or Password!");
      }
      
      // console.log(data);
    }   
  });
  }

  function logout(){
    $.ajax({
    url: "logout.php",
    type: 'GET',
    success: function (data) {
      location.reload();
      // console.log(data);
    }   
  });
  }
</script>

<script>
    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    })
</script>

</body>
</html>
