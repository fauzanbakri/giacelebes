<?php
include 'config.php';
$id = $_POST['id'];
$name = $_POST['name'];
$description = $_POST['description'];
$fuel = $_POST['fuel'];
$status;
if(isset($_POST['status-checkbox'])){
    $status = 0;
}else{
    $status = 1;
}
// echo $status; die();
$inphour = $_POST['time_hour']*60;
$inpminute = $_POST['time_minute'];
$notiftime = $inphour + $inpminute;
$old_img = $_POST['old_image'];
// if(isset($_POST['sbm'])){
    $folder = './photo/';
    $img_name = $_FILES['engine_image']['name'];
    $img_src = $_FILES['engine_image']['tmp_name'];
    //$img_ext = strtolower(end(explode('.', $img_name)));
    $img_ext = substr(strrchr($img_name, '.'), 1);
    $new_name = $id.'.'.$img_ext;
    $img_size = $_FILES['engine_image']['size'];
    $valid_ext = array('jpg', 'jpeg', 'png' );
    $max_size = 1024 * 200;

if($img_name){
    //script Lama
    if(in_array($img_ext, $valid_ext)){
        if($img_size <= $max_size){
            unlink('photo/'.$old_img);

            move_uploaded_file($img_src, $folder.$new_name);
            $q = $con->query("UPDATE hour_data SET 
                        name = '$name', 
                        engine_description = '$description', 
                        engine_picture = '$new_name', 
                        engine_fuel = '$fuel', 
                        time_notification = '$notiftime'
                        WHERE id = '$id'");
            if($q){
                // header("location:index.php");
                echo "ok";
            }else{
                echo 'failed';
                }
        }else{
            echo 'max image size 200kb';
        }
    }else{
        echo 'invalid image extensions';
    } 
    //End Script Lama
}else{
    $q = $con->query("UPDATE hour_data SET 
                        id ='$id', 
                        name = '$name', 
                        engine_description = '$description', 
                        engine_fuel = '$fuel', 
                        time_notification = '$notiftime',
                        notif = '$status'
                        WHERE id = '$id'");
            if($q){
                // header("location:index.php");
                echo "ok";
            }else{
                echo 'failed';
            }
}
?>