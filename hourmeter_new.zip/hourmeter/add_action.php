<?php
include 'config.php';
$id = $_POST['id'];
$name = $_POST['name'];
$description = $_POST['description'];
$fuel = $_POST['fuel'];
$inphour = $_POST['time_hour']*60;
$inpminute = $_POST['time_minute'];
$notiftime = $inphour + $inpminute;
// if(isset($_POST['sbm'])){
    $folder = './photo/';
    $img_name = $_FILES['engine_image']['name'];
    $img_src = $_FILES['engine_image']['tmp_name'];
    //$img_ext = strtolower(end(explode('.', $img_name)));
    $img_ext = substr(strrchr($img_name, '.'), 1);
    $new_name = $id.'.'.$img_ext;
    $img_size = $_FILES['engine_image']['size'];
    $valid_ext = array('jpg', 'jpeg', 'png' );
    $max_size = 1024 * 200;

    if(in_array($img_ext, $valid_ext)){
        if($img_size <= $max_size){
            move_uploaded_file($img_src, $folder.$new_name);
            $q = $con->query("INSERT INTO hour_data (id, name, engine_description, engine_picture, engine_fuel, time_notification, notif) VALUES ('$id', '$name', '$description', '$new_name', '$fuel', '$notiftime','')");
            if($q){
                // header("location:index.php");
                echo "ok";
            }else{
                echo 'failed';
                }
        }else{
            echo 'max image size 200kb';
        }
    }else{
        echo 'invalid image extensions';
    }     

// }

// $id = $_POST['id'];
// $name = $_POST['name'];
// $q = $con->query("INSERT INTO hour_data (id, name, timerun) VALUES ('$id', '$name', '')");

// if($q){
//     header("location:index.php");
// }
?>